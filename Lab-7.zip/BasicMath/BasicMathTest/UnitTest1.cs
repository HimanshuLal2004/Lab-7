using BasicMath;
namespace BasicMathTest
{
    [TestFixture]
    public class Tests
    {
        BasicMathClass basic_math_class;

        [SetUp]
        public void Setup()
        {
            basic_math_class = new BasicMathClass();
        }

       
        [Test]
        public void addTest()
        {
            double result = basic_math_class.add(7, 7);
            Assert.That(result, Is.EqualTo(14));
        }
        [Test]
        public void subTest()
        {
            double result = basic_math_class.subtract(7, 7);
            Assert.That(result, Is.EqualTo(0));
        }
        [Test]
        public void multTest()
        {
            double result = basic_math_class.multiply(7, 7);
            Assert.That(result, Is.EqualTo(49));
        }
        [Test]
        public void divTest()
        {
            double result = basic_math_class.divide(7, 7);
            Assert.That(result, Is.EqualTo(1));
        }
    }
}